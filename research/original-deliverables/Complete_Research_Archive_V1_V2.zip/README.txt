COMPLETE RESEARCH ARCHIVE — V1 & V2

00_Original_Brief_and_Phase_1: original research instructions and model inventory.
01_Version_1: original journal, resource directory, annotated evidence, ledger, original LaTeX package, working source, figures, compilation outputs and layout reviews.
02_Version_2: revised journal, resource directory, annotated evidence, ledger, original LaTeX package, working source, figures, compilation outputs and layout reviews.

Begin with the Version 2 Deliverables PDF. The original ZIP packages are preserved unchanged; the Working_Source directories retain loose source files and build outputs, including duplicates.
This archive contains the research artifacts available in the conversation, not complete offline copies of all external websites or original source publications. External links and evidence summaries are in the resource directories and ledgers.
SHA256SUMS.txt inventories the archived files.
